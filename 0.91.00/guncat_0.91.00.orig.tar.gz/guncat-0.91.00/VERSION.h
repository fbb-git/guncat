#include "VERSION"
SUBST(_CurVers_)(VERSION)
SUBST(_CurYrs_)(YEARS)
